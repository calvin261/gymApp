<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('AUDITORIA')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">

        <div class="grid grid-rows-3 grid-flow-col gap-4 max-w-4xl mx-auto">



            <!--[if BLOCK]><![endif]--><?php if($client->rutina): ?>

                <div class="row-span-3">
                    <h2 class="text-5xl text-center my-2 font-extrabold dark:text-white">
                        <?php echo $client->rutina->Nombre; ?>

                    </h2>
                    <div id="accordion-open"
                        data-accordion="open">
                        <h2 id="accordion-open-heading-1">
                            <button type="button"
                                class="flex items-center justify-between w-full p-5 font-medium rtl:text-right
                         text-gray-500 border border-b-0 border-gray-200 rounded-t-xl focus:ring-4
                          focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700
                          dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                                data-accordion-target="#accordion-open-body-1"
                                <?php if($dayOfWeek != 'monday'): ?> aria-expanded="false"  <?php else: ?> aria-expanded="true" <?php endif; ?>
                                aria-controls="accordion-open-body-1">
                                <span class="flex items-center">Lunes</span>
                                <svg data-accordion-icon
                                    class="w-3 h-3 rotate-180 shrink-0"
                                    aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 10 6">
                                    <path stroke="currentColor"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M9 5 5 1 1 5" />
                                </svg>
                            </button>
                        </h2>
                        <div id="accordion-open-body-1"
                            class="hidden"
                            aria-labelledby="accordion-open-heading-1">
                            <div class="p-5 border border-b-0 border-gray-200 dark:border-gray-700 dark:bg-gray-900">
                                <p class="mb-2 text-gray-500 dark:text-gray-400"><?php echo $client->rutina->Lunes; ?></p>

                            </div>
                        </div>
                        <h2 id="accordion-open-heading-2">
                            <button type="button"
                                class="flex items-center justify-between w-full p-5 font-medium rtl:text-right
                         text-gray-500 border border-b-0 border-gray-200 focus:ring-4
                         focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700
                          dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                                data-accordion-target="#accordion-open-body-2"
                                <?php if($dayOfWeek != 'tuesday'): ?> aria-expanded="false"  <?php else: ?> aria-expanded="true" <?php endif; ?>
                                aria-controls="accordion-open-body-2">
                                <span class="flex items-center">Martes</span>
                                <svg data-accordion-icon
                                    class="w-3 h-3 rotate-180 shrink-0"
                                    aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 10 6">
                                    <path stroke="currentColor"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M9 5 5 1 1 5" />
                                </svg>
                            </button>
                        </h2>
                        <div id="accordion-open-body-2"
                            class="hidden"
                            aria-labelledby="accordion-open-heading-2">
                            <div class="p-5 border border-b-0 border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400"><?php echo $client->rutina->Martes; ?></p>
                            </div>
                        </div>
                        <h2 id="accordion-open-heading-3">
                            <button type="button"
                                class="flex items-center justify-between w-full p-5 font-medium rtl:text-right
                         text-gray-500 border border-gray-200 focus:ring-4 focus:ring-gray-200
                          dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400
                           hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                                data-accordion-target="#accordion-open-body-3"
                                <?php if($dayOfWeek != 'wednesday'): ?> aria-expanded="false"  <?php else: ?> aria-expanded="true" <?php endif; ?>
                                aria-controls="accordion-open-body-3">
                                <span class="flex items-center"> Miercoles</span>
                                <svg data-accordion-icon
                                    class="w-3 h-3 rotate-180 shrink-0"
                                    aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 10 6">
                                    <path stroke="currentColor"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M9 5 5 1 1 5" />
                                </svg>
                            </button>
                        </h2>
                        <div id="accordion-open-body-3"
                            class="hidden"
                            aria-labelledby="accordion-open-heading-3">
                            <div class="p-5 border border-t-0 border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400"><?php echo $client->rutina->Miercoles; ?></p>
                            </div>
                        </div>
                        <h2 id="accordion-open-heading-4">
                            <button type="button"
                                class="flex items-center justify-between w-full p-5 font-medium rtl:text-right
                         text-gray-500 border border-gray-200 focus:ring-4 focus:ring-gray-200
                          dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400
                           hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                                data-accordion-target="#accordion-open-body-4"
                                <?php if($dayOfWeek != 'thursday'): ?> aria-expanded="false"  <?php else: ?> aria-expanded="true" <?php endif; ?>
                                aria-controls="accordion-open-body-4">
                                <span class="flex items-center">Jueves</span>
                                <svg data-accordion-icon
                                    class="w-3 h-3 rotate-180 shrink-0"
                                    aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 10 6">
                                    <path stroke="currentColor"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M9 5 5 1 1 5" />
                                </svg>
                            </button>
                        </h2>
                        <div id="accordion-open-body-4"
                            class="hidden"
                            aria-labelledby="accordion-open-heading-4">
                            <div class="p-5 border border-t-0 border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400"><?php echo $client->rutina->Jueves; ?></p>
                            </div>
                        </div>
                        <h2 id="accordion-open-heading-5">
                            <button type="button"
                                class="flex items-center justify-between w-full p-5 font-medium rtl:text-right
                         text-gray-500 border border-gray-200 focus:ring-4 focus:ring-gray-200
                          dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400
                           hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                                data-accordion-target="#accordion-open-body-5"
                                <?php if($dayOfWeek != 'friday'): ?> aria-expanded="false"  <?php else: ?> aria-expanded="true" <?php endif; ?>
                                aria-controls="accordion-open-body-5">
                                <span class="flex items-center">Viernes</span>
                                <svg data-accordion-icon
                                    class="w-3 h-3 rotate-180 shrink-0"
                                    aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 10 6">
                                    <path stroke="currentColor"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M9 5 5 1 1 5" />
                                </svg>
                            </button>
                        </h2>
                        <div id="accordion-open-body-5"
                            class="hidden"
                            aria-labelledby="accordion-open-heading-5">
                            <div class="p-5 border border-t-0 border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400"><?php echo $client->rutina->Viernes; ?></p>
                            </div>
                        </div>
                        <h2 id="accordion-open-heading-6">
                            <button type="button"
                                class="flex items-center justify-between w-full p-5 font-medium rtl:text-right
                         text-gray-500 border border-gray-200 focus:ring-4 focus:ring-gray-200
                          dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400
                           hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                                data-accordion-target="#accordion-open-body-6"
                                <?php if($dayOfWeek != 'saturday'): ?> aria-expanded="false"  <?php else: ?> aria-expanded="true" <?php endif; ?>
                                aria-controls="accordion-open-body-6">
                                <span class="flex items-center">Sabado</span>
                                <svg data-accordion-icon
                                    class="w-3 h-3 rotate-180 shrink-0"
                                    aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 10 6">
                                    <path stroke="currentColor"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M9 5 5 1 1 5" />
                                </svg>
                            </button>
                        </h2>
                        <div id="accordion-open-body-6"
                            class="hidden"
                            aria-labelledby="accordion-open-heading-6">
                            <div class="p-5 border border-t-0 border-gray-200 dark:border-gray-700">
                                <p class="mb-2 text-gray-500 dark:text-gray-400"><?php echo $client->rutina->Sabado; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="flex justify-end">
                        <button type="button"
                            wire:click="udpateClientRutina(<?php echo e($client); ?>)"
                            class="hover:underline hover:text-blue-500  font-medium rounded-lg text-xs px-3 py-2
                      me-2 mb-2 ">Cambiar
                            de Rutina</button>

                    </div>

                </div>
            <?php else: ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $rutinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rutina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="h-64 sm:px-2 lg:px-4">
                        <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                            <div class="bg-white shadow-md rounded-lg p-6">

                                <div class="flex items-center">

                                    <h2 class="ms-3 text-xl font-semibold text-gray-900">
                                        <a href="https://laravel.com/docs"
                                            class="hover:text-blue-500">Rutinas</a>
                                    </h2>
                                </div>
                                <div class="grid grid-cols-2 gap-x-4 mt-4 text-gray-500 text-sm">
                                    <div class="flex items-center">
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 24 24"
                                            class="w-4 h-4 mr-1.5 fill-current text-gray-500">
                                            <path fill-rule="evenodd"
                                                d="M6.854 3.646a.5.5 0 0 1 .708 0l5.5 5.5a.5.5 0 0 1 0
                                         .708l-5.5 5.5a.5.5 0 0 1-.708-.708L11.793 9 6.854 4.146a.5.5 0 0 1 0-.708z" />
                                        </svg>
                                        <p class="font-semibold">Nombre:</p>
                                        <p class="ml-1"><?php echo $rutina->Nombre; ?></p>
                                    </div>

                                </div>

                                <button wire:click="udpateClientRutina(<?php echo e($client); ?>,<?php echo e($rutina->id); ?>)"
                                    class="bg-blue-600 m-5 px-3 py-2
                                 rounded-lg text-white hover:bg-blue-800">Escojer</button>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <div class="  h-64 sm:px-2 lg:px-4">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                    <div class="bg-white shadow-md rounded-lg p-6">
                        <!--[if BLOCK]><![endif]--><?php if($salud): ?>
                            <div class="flex items-center">

                                <h2 class="ms-3 text-xl font-semibold text-gray-900">
                                    <a href="https://laravel.com/docs"
                                        class="hover:text-blue-500">Estado de Salud</a>
                                </h2>
                            </div>
                            <div class="grid grid-cols-2 gap-x-4 mt-4 text-gray-500 text-sm">
                                <div class="flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 24 24"
                                        class="w-4 h-4 mr-1.5 fill-current text-gray-500">
                                        <path fill-rule="evenodd"
                                            d="M6.854 3.646a.5.5 0 0 1 .708 0l5.5 5.5a.5.5 0 0 1 0
                                         .708l-5.5 5.5a.5.5 0 0 1-.708-.708L11.793 9 6.854 4.146a.5.5 0 0 1 0-.708z" />
                                    </svg>
                                    <p class="font-semibold">Calorías:</p>
                                    <p class="ml-1"><?php echo e($salud->calorias); ?></p>
                                </div>
                                <div class="flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 24 24"
                                        class="w-4 h-4 mr-1.5 fill-current text-gray-500">
                                        <path fill-rule="evenodd"
                                            d="M6.854 3.646a.5.5 0 0 1 .708 0l5.5 5.5a.5.5 0 0 1 0
                                             .708l-5.5 5.5a.5.5 0 0 1-.708-.708L11.793 9 6.854 4.146a
                                             .5.5 0 0 1 0-.708z" />
                                    </svg>
                                    <p class="font-semibold">Altura:</p>
                                    <p class="ml-1"><?php echo e($salud->altura); ?></p>
                                </div>
                                <div class="flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 24 24"
                                        class="w-4 h-4 mr-1.5 fill-current text-gray-500">
                                        <path fill-rule="evenodd"
                                            d="M6.854 3.646a.5.5 0 0 1 .708 0l5.5 5.5a.5.5 0 0 1 0
                                             .708l-5.5 5.5a.5.5 0 0 1-.708-.708L11.793 9 6.854 4.146a.5.5 0 0 1 0-.708z" />
                                    </svg>
                                    <p class="font-semibold">Peso:</p>
                                    <p class="ml-1"><?php echo e($salud->peso); ?></p>
                                </div>
                                <div class="flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 24 24"
                                        class="w-4 h-4 mr-1.5 fill-current text-gray-500">
                                        <path fill-rule="evenodd"
                                            d="M6.854 3.646a.5.5 0 0 1 .708 0l5.5 5.5a.5.5 0 0 1 0
                                             .708l-5.5 5.5a.5.5 0 0 1-.708-.708L11.793 9 6.854 4.146a.5.5 0 0 1 0-.708z" />
                                    </svg>
                                    <p class="font-semibold">Grasa:</p>
                                    <p class="ml-1"><?php echo e($salud->grasa); ?></p>
                                </div>
                                <div>
                                    <a href="<?php echo e(route('saluds.edit', $salud)); ?>">
                                        <button
                                            class="bg-blue-600 m-5 px-3 py-2
                                     rounded-lg text-white hover:bg-blue-800">Actualizar</button>
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo e(route('saluds.create')); ?>">
                                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['class' => 'bg-green-400 m-5 hover:bg-green-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-green-400 m-5 hover:bg-green-600']); ?>Registrar mi estado
                                    fisico <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                            </a>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>

            <!--[if BLOCK]><![endif]--><?php if($client->plan): ?>
                <div class="row-span-2  h-64 sm:px-2 lg:px-4">
                    <div class=" bg-white overflow-hidden shadow-xl sm:rounded-lg">
                        <div class="px-4 py-4">
                            <h2 class="text-lg font-semibold text-gray-800"><?php echo e($client->plan->nombre); ?></h2>
                            <p class="text-sm text-gray-600"><?php echo e($client->plan->descripcion); ?></p>
                            <div class="mt-4 flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor"
                                    class="w-4 h-4 text-blue-500">
                                    <path stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                                </svg>
                                <p class="ml-1 text-sm text-gray-600">
                                    <?php echo e($client->plan->validez); ?> <?php echo e($client->plan->validez === 1 ? 'mes' : 'meses'); ?>

                                    de
                                    validez
                                </p>
                            </div>
                            <div class="mt-4 flex items-baseline">
                                <p class="text-2xl font-semibold text-gray-800">$ <?php echo e($client->plan->precio); ?></p>
                                <p class="ml-1 text-sm text-gray-600">/ mes</p>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php if($client->plan->pagado == 0): ?>
                                <button wire:click="$set('modalPagar', true)"
                                    class="mt-6 w-full bg-yellow-500 text-white rounded-lg py-2 font-semibold
                         hover:bg-yellow-600 focus:outline-none focus:bg-yellow-600 transition
                           duration-300">Pagar</button>
                            <?php else: ?>
                                <a href="<?php echo e(route('clients.comprobante', $client)); ?>">
                                    <button
                                        class="mt-6 w-full bg-blue-500 text-white rounded-lg py-2 font-semibold
                 hover:bg-blue-600 focus:outline-none focus:bg-blue-600 transition
                   duration-300">Imprimir
                                        Comprobante</button>
                                </a>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        </div>
                    </div>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <?php if (isset($component)) { $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dialog-modal','data' => ['wire:model.live' => 'modalPagar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dialog-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.live' => 'modalPagar']); ?>
             <?php $__env->slot('title', null, []); ?> 
                Pago del Plan: <?php echo e($client->plan->nombre); ?>

             <?php $__env->endSlot(); ?>

             <?php $__env->slot('content', null, []); ?> 
                <div>
                    <p class="ml-1 text-sm text-gray-600">
                        <?php echo e($client->plan->validez); ?> <?php echo e($client->plan->validez === 1 ? 'mes' : 'meses'); ?> de
                        validez
                    </p>
                </div>


             <?php $__env->endSlot(); ?>

             <?php $__env->slot('footer', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => 'udpateClientPago('.e($client).', true)','wire:loading.attr' => 'disabled']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'udpateClientPago('.e($client).', true)','wire:loading.attr' => 'disabled']); ?>
                    <?php echo e(__('Pagar')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $attributes = $__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__attributesOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f)): ?>
<?php $component = $__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f; ?>
<?php unset($__componentOriginal49bd1c1dd878e22e0fb84faabf295a3f); ?>
<?php endif; ?>

    </div>
</div>
<?php /**PATH E:\laragon\www\gymApp\resources\views/dashboard.blade.php ENDPATH**/ ?>