<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Editar Rutina')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 py-10">
        <div class="mt-10 sm:mt-0">
            <div class="md:grid md:grid-cols-3 md:gap-6">
                <div class="md:col-span-1">
                    <div class="px-4 sm:px-0">
                        <h3 class="text-lg font-medium leading-6 text-gray-900">Información de la Rutina</h3>
                    </div>
                </div>
                <div class="mt-5 md:mt-0 md:col-span-2">
                    <form action="<?php echo e(route('rutinas.update', $rutina)); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="shadow overflow-hidden sm:rounded-md">
                            <div class="px-4 py-5 bg-white sm:p-6">
                                <div>
                                    <label for="first_name"
                                        class="block text-sm font-medium text-gray-700">Nombre</label>
                                    <input type="text"
                                        name="nombre"
                                        value="<?php echo e($rutina->Nombre); ?>"
                                        autocomplete="false"
                                        class="mt-1 focus:ring-red-500 focus:border-red-500 block w-full editor
                                        shadow-sm sm:text-sm border-gray-300 rounded-md">
                                </div>
                                <div>
                                    <label for="first_name"
                                        class="block text-sm font-medium text-gray-700">Lunes</label>
                                    <textarea type="text"
                                        name="lunes"
                                        autocomplete="false"
                                        class="mt-1 focus:ring-red-500 focus:border-red-500 block w-full editor
                                        shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo e($rutina->Lunes); ?>

                                    </textarea>
                                </div>
                                <div>
                                    <label for="first_name"
                                        class="block text-sm font-medium text-gray-700">Martes</label>
                                    <textarea type="text"
                                        name="martes"
                                        autocomplete="false"
                                        class="mt-1 focus:ring-red-500 focus:border-red-500 block w-full editor
                                        shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo e($rutina->Martes); ?>

                                    </textarea>
                                </div>
                                <div>
                                    <label for="first_name"
                                        class="block text-sm font-medium text-gray-700">Miercoles</label>
                                    <textarea type="text"
                                        name="miercoles"
                                        autocomplete="false"
                                        class="mt-1 focus:ring-red-500 focus:border-red-500 block w-full editor
                                        shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo e($rutina->Miercoles); ?>

                                    </textarea>
                                </div>
                                <div>
                                    <label for="first_name"
                                        class="block text-sm font-medium text-gray-700">Jueves</label>
                                    <textarea type="text"
                                        name="jueves"
                                        autocomplete="false"
                                        class="mt-1 focus:ring-red-500 focus:border-red-500 block w-full editor
                                        shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo e($rutina->Jueves); ?>

                                    </textarea>
                                </div>
                                <div>
                                    <label for="first_name"
                                        class="block text-sm font-medium text-gray-700">Viernes</label>
                                    <textarea type="text"
                                        name="viernes"
                                        autocomplete="false"
                                        class="mt-1 focus:ring-red-500 focus:border-red-500 block w-full editor
                                        shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo e($rutina->Viernes); ?>

                                    </textarea>
                                </div>
                                <div>
                                    <label for="first_name"
                                        class="block text-sm font-medium text-gray-700">Sabado</label>
                                    <textarea type="text"
                                        name="sabado"
                                        autocomplete="false"
                                        class="mt-1 focus:ring-red-500 focus:border-red-500 block w-full editor
                                        shadow-sm sm:text-sm border-gray-300 rounded-md"><?php echo e($rutina->Sabado); ?>

                                    </textarea>
                                </div>

                                <div class="px-4 py-3  text-right sm:px-6">
                                    <button type="submit"
                                        class="inline-flex justify-center py-2 px-4 border border-transparent
                                        shadow-sm text-sm font-medium rounded-md text-white bg-red-600
                                        hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2
                                        focus:ring-red-500">
                                        Guardar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
        crossorigin="anonymous"></script>
    <script src="https://cdn.tiny.cloud/1/2ko1unqj7wxnnx8e7847a5ab0606os0sl8185ebbs7a25vqb/tinymce/6/tinymce.min.js"
        referrerpolicy="origin"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tinymce/tinymce-jquery@2/dist/tinymce-jquery.min.js"></script>
    <script>
        $('.editor').tinymce({
            height: 250,
            menubar: false,
            plugins: [
                'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
                'anchor', 'searchreplace', 'visualblocks', 'fullscreen',
                'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount', 'image'
            ],
            toolbar: 'undo redo | blocks | bold italic backcolor | ' +
                'alignleft aligncenter alignright alignjustify | ' +
                ' link image | help',
            image_title: true,
            a11y_advanced_options: true,
            automatic_uploads: true,
            images_upload_url: '/upload',
            file_picker_types: 'image',
            images_upload_base_path:'http://127.0.0.1:8000/',
            file_picker_callback: (callback, value, meta) => {
                const input = document.createElement('input');
                input.setAttribute('type', 'file');
                input.setAttribute('accept', 'image/*');

                input.addEventListener('change', (e) => {
                    const file = e.target.files[0];

                    const reader = new FileReader();
                    reader.addEventListener('load', () => {
                        const id = 'blobid' + (new Date()).getTime();
                        const blobCache = tinymce.activeEditor.editorUpload.blobCache;
                        const base64 = reader.result.split(',')[1];
                        const blobInfo = blobCache.create(id, file, base64);
                        blobCache.add(blobInfo);

                        /* call the callback and populate the Title field with the file name */
                        cb(blobInfo.blobUri(), {
                            title: file.name
                        });
                    });
                    reader.readAsDataURL(file);
                });

                input.click();
            },
            content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }'
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\laragon\www\gymApp\resources\views/admin/rutinas/edit.blade.php ENDPATH**/ ?>