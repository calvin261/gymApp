<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostTasksController extends Controller
{
    public function upload(Request $request)
    {
        dd($request);
        $imgPath = request()->file('file')->store('uploads', 'public');
        return response()->json(['location' => 'storage/' . $imgPath]);
    }
}
