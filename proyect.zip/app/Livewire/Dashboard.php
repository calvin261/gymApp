<?php

namespace App\Livewire;

use App\Models\Client;
use App\Models\Plan;
use App\Models\Rutina;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use function Spatie\LaravelPdf\Support\pdf;

class Dashboard extends Component
{
    public $modalPagar = false; // Inicializar la variable modalPagar como false
    public $dayOfWeek;

    public function mount()
    {
        // Inicializamos la variable $dayOfWeek en el método mount()
        $this->dayOfWeek = strtolower(date('l'));
    }
    public function render()
    {
        $user = Auth::user();
        $client = Client::where('correo', $user->email)->firstOrFail();
        $rutinas = Rutina::all();
        $salud = $client->salud;
        return view('dashboard', [
            'salud' => $salud,
            'client' => $client,
            'rutinas' => $rutinas
        ]);
    }
    public function udpateClientRutina(Client $client, $rutina_id = null)
    {

        $client->rutina_id = $rutina_id;
        $client->save();
    }
    public function udpateClientPago(Client $client, $pago)
    {

        $plan = Plan::find($client->plan->id);
        $plan->pagado = $pago;
        $plan->save();
        $this->modalPagar = false;
    }
}
