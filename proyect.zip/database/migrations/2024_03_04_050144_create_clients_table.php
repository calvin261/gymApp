<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->id();
            $table->String("nombre");
            $table->String("telefono");
            $table->String("correo");
            $table->String("fechaNacimiento");
            $table->String("direccion");
            $table->String("provincia");
            $table->String("ciudad");
            $table->bigInteger('plan_id')->unsigned();
            $table->timestamps();
            $table->foreign('plan_id')
                ->references('id')
                ->on('plans')
                ->onCascade('delete');
            $table->bigInteger('rutina_id')->unsigned();
            $table->timestamps();
            $table->foreign('rutina_id')
                ->references('id')
                ->on('rutinas');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('clients');
    }
};
